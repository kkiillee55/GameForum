'''
privileges of admin

create new game category
delete existing game category

'''